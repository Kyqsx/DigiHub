import { z } from 'zod'

export const searchSchema = z.object({
  q: z.string().trim().max(100, 'Use no máximo 100 caracteres.'),
})
