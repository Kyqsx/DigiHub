package com.kovax.digihub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigihubApplicationTests {

	@Test
	void contextLoads() {
	}

}
